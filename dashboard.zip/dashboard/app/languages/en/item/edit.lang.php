<?php



$_['title']  = 'Edit Item';
$_['text_edit_btn']  = 'Save';
$_['text_name_ph']  = 'Item Name';
$_['text_price_ph'] = 'Item Price';
$_['text_rate_ph'] = 'Item Rate';
$_['text_desc_ph'] = 'Item Description';
$_['text_legend'] = 'Item Data';