<?php 


$_['title'] = 'Items';
$_['text_view_title'] = 'Items';
$_['text_id'] = 'Item ID';
$_['text_name'] = 'Item Name';
$_['text_price'] = 'Item Price';
$_['text_rate'] = 'Item rate';
$_['text_options'] = 'Options';
$_['text_edit_item'] = 'Edit';
$_['text_delete_item'] = 'Delete';
