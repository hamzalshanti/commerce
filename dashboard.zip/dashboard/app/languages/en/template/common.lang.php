<?php


$_['text_board']      		= 'Dashboard';
$_['text_show_stat']  		= 'Statistics';

$_['text_categories'] 		= 'Categories';
$_['text_show_categories']  = 'Display Categories';
$_['text_add_category']    	= 'Add Category';

$_['text_items'] 			= 'Items';
$_['text_show_items']   	= 'Display Items';
$_['text_add_item']    		= 'Add Item';

$_['text_users'] 			= 'Users';
$_['text_show_users']   	= 'Display Users';
$_['text_add_user']    		= 'Add User';

$_['text_lang']       		= 'Language';
$_['text_ar']        		= 'Arabic';
$_['text_en']         		= 'English';