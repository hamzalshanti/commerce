<?php


$_['title']  = 'Edit Category';
$_['text_edit_btn']  = 'Save';
$_['text_name_ph']  = 'Category Name';
$_['text_desc_ph'] = 'Category Description';
$_['text_legend'] = 'Category Details';