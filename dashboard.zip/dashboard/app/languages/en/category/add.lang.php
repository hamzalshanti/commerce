<?php



$_['title'] = 'Add Category';
$_['text_legend'] = 'Category Details';
$_['text_name_ph'] = 'Category Name';
$_['text_desc_ph'] = 'Category Desc';
$_['text_add_btn'] = 'Save';