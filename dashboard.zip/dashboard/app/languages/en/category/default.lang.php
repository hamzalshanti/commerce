<?php

$_['title'] = 'Categories';
$_['text_view_title'] = 'Categories';
$_['text_id'] = 'Number';
$_['text_name'] = 'Category Name';
$_['text_desc'] = 'Category desc';
$_['text_options'] = 'Options';