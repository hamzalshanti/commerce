<?php

$_['title'] = 'Users';
$_['text_view_title'] = 'Users';
$_['text_id'] = 'Number';
$_['text_name'] = 'User Name';
$_['text_email'] = 'Email';
$_['text_position'] = 'Position';
$_['text_options'] = 'Options';