<?php

$_['title'] = 'Edit User';
$_['text_legend'] = 'User Details';
$_['text_name_ph'] = 'User Name';
$_['text_email_ph'] = 'Eamil';
$_['text_pass_ph'] = 'Password';
$_['text_confirm_pass_ph'] = 'Confirm Password';
$_['text_position_manager_ph'] = 'Manager';
$_['text_position_user_ph'] = 'User';
$_['text_edit_btn'] = 'Save';