<?php


$_['title'] = 'dashboard';
$_['text_welcome'] = 'Welcome to Dashboard';
$_['users'] = 'Users';
$_['categories'] = 'Categories';
$_['items'] = 'Items';
$_['sales'] = 'Sales';
$_['stat1'] = 'Statictics One';
$_['stat2'] = 'Statictics Two';

$_['last_users'] = 'Last Users';
$_['text_order_table_name'] = 'Customer Name';
$_['text_order_table_item'] = 'Item Name';
$_['text_order_table_quntitiy'] = 'Quntitiy';
$_['text_order_table_status'] = 'Status';


$_['last_orders'] = 'Last Orders';
$_['text_user_table_username'] = 'Customer UserName';
$_['text_user_table_name'] = 'Customer Name';
$_['text_user_table_options'] = 'Options';