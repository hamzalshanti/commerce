<?php

$_['title'] = 'اضافة قسم';
$_['text_legend'] = 'بيانات القسم';
$_['text_name_ph'] = 'اسم القسم';
$_['text_desc_ph'] = 'وصف القسم';
$_['text_add_btn'] = 'حفظ';