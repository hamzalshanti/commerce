<?php

$_['title'] = 'الاقسام';
$_['text_view_title'] = 'الاقسام';
$_['text_id'] = 'الرقم';
$_['text_name'] = 'اسم القسم';
$_['text_desc'] = 'وصف القسم';
$_['text_options'] = 'خيارات';