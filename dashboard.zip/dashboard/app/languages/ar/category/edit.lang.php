<?php


$_['title']  = 'تعديل قسم';
$_['text_edit_btn']  = 'حفظ';
$_['text_name_ph']  = 'اسم القسم';
$_['text_desc_ph'] = 'وصف القسم';
$_['text_legend'] = 'بيانات الاقسام';