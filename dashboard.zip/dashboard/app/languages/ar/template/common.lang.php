<?php


$_['text_board']      		= 'لوحة التحكم';
$_['text_show_stat']  		= 'الاحصائيات';

$_['text_categories'] 		= 'الاقسام';
$_['text_show_categories']  = 'عرض الاقسام';
$_['text_add_category']    	= 'اضافة قسم';

$_['text_items'] 			= 'المنتجات';
$_['text_show_items']   	= 'عرض المنتجات';
$_['text_add_item']    		= 'اضافة منتج';

$_['text_users'] 			= 'المستخدمون';
$_['text_show_users']   	= 'عرض المستخدمون';
$_['text_add_user']    		= 'اضافة مستخدم';

$_['text_lang']       		= 'اللغة';
$_['text_ar']        		= 'عربي';
$_['text_en']         		= 'انجليزي';