<?php


$_['title'] = 'لوحة التحكم';
$_['text_welcome'] = 'مرحبا بك في اللوحة الرئيسية';
$_['users'] = 'المستخدمون';
$_['categories'] = 'الاقسام';
$_['items'] = 'المنتجات';
$_['sales'] = 'المبيعات';
$_['stat1'] = 'الاحصائية الاولى';
$_['stat2'] = 'الاحصائية الثانية';

$_['last_users'] = 'اخر المستخدمين';
$_['text_order_table_name'] = 'اسم الزبون';
$_['text_order_table_item'] = 'اسم المنتج';
$_['text_order_table_quntitiy'] = 'الكمية';
$_['text_order_table_status'] = 'الحالة';

$_['last_orders'] = 'اخر الطلبات';
$_['text_user_table_username'] = 'اليوزر';
$_['text_user_table_name'] = 'اسم الزبون';
$_['text_user_table_options'] = 'خيارات';
