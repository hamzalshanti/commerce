<?php

$_['title'] = 'اضافة مستخدم';
$_['text_legend'] = 'بيانات المستخدم';
$_['text_name_ph'] = 'اسم المستخدم';
$_['text_email_ph'] = 'الايميل';
$_['text_pass_ph'] = 'كلمة المرور';
$_['text_confirm_pass_ph'] = 'تاكيد كلمة المرور';
$_['text_position_manager_ph'] = 'مدير';
$_['text_position_user_ph'] = 'مستخدم';
$_['text_add_btn'] = 'حفظ';