<?php

$_['title'] = 'المستخدمين';
$_['text_view_title'] = 'كافة المستخدمين';
$_['text_id'] = 'الرقم';
$_['text_name'] = 'اسم المستخدم';
$_['text_email'] = 'الايميل';
$_['text_position'] = 'الرتبة';
$_['text_options'] = 'خيارات';