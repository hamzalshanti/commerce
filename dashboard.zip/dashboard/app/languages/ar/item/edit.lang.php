<?php




$_['title']  = 'تعديل منتج';
$_['text_edit_btn']  = 'حفظ';
$_['text_name_ph']  = 'اسم المنتج';
$_['text_price_ph'] = 'سعر المنتج';
$_['text_rate_ph'] = 'تقييم المنتج';
$_['text_desc_ph'] = 'وصف المنتج';
$_['text_legend'] =  'بيانات المنتج';