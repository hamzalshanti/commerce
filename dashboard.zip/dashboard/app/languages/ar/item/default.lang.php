<?php




$_['title'] = 'المنتجات';
$_['text_view_title'] = 'المنتجات';
$_['text_id'] = 'رقم المنتج';
$_['text_name'] = 'اسم المنتج';
$_['text_price'] = 'سعر المنتج';
$_['text_rate'] = 'تقييم المنتج';
$_['text_options'] = 'خيارات';
$_['text_edit_item'] = 'تعديل';
$_['text_delete_item'] = 'حذف';