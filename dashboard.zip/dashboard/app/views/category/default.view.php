
<h2 class="emp-title"><?= $text_view_title ?></h2>

<div class="table-container">
<table id="table_id" class="display">
	<thead>
        <tr>
            <th><?= $text_id ?></th>
			<th><?= $text_name ?></th>
			<th><?= $text_desc ?></th>
			<th><?= $text_options ?></th>
        </tr>
    </thead>
    <tbody>
<?php 
	if(!isset($category))
	{
		Echo 'No Data Found';
	}
	else{
	$count = 1;
	while ($cat = mysqli_fetch_assoc($category)) {
?>
	<tr>
		<td><?php echo $count++ ?></td>
		<td><?php echo $cat['cat_name'] ?></td>
		<td><?php echo $cat['cat_desc'] ?></td>
		<td><a href="<?php echo 'http://localhost/commerce/dashboard/public/category/edit/' . $cat['id'] ?>"><i class="far fa-edit"></i>&nbsp;</a> &nbsp;
		<a href="<?php echo 'http://localhost/commerce/dashboard/public/category/delete/' . $cat['id'] ?>" onclick="confirm('Are You Sure?')"><i class="far fa-trash-alt"></i>&nbsp;</a></td>
	</tr>
<?php
	}
	}
?>
    </tbody>
</table>
</div>

