
	<?php 
	$cat = mysqli_fetch_assoc($category);
	 ?>
<form method="post" enctype="multipart/form-data">
	<fieldset class="add-form">
		<legend><?= $text_legend ?></legend>
	  
	  	<div class="input-wrap">
	  		<input type="text"  name="cat_name" placeholder='<?= $text_name_ph?>' value="<?php echo $cat['cat_name'] ?>">	  
	  	</div>

		<div class="input-wrap">
			<input type="file" name="cat_img">
		</div>
		
	  	<div class="input-wrap mt-2">
			<textarea  class='form-control' name="cat_desc" placeholder='<?= $text_desc_ph?>'><?= $cat['cat_desc']?></textarea>	  
		</div>
	  	
	  	<br>
	  	<br>
	  	<input type="submit" name="edit" value="<?= $text_edit_btn?>">
	</fieldset>
</form>

<?php 

if(isset($result))
	{ ?>

	<div class="alert alert-success" role="alert">
  		Edit Done
	</div>

<?php } ?>



