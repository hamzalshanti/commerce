
<form method="post" enctype="multipart/form-data">
	<fieldset class="add-form">
		<legend><?= $text_legend ?></legend>
		  
		<div class="input-wrap">
			  <input type="text"  name="cat_name" placeholder='<?= $text_name_ph?>'>			  
		</div>

		<div class="input-wrap">
			<input type="file" name="cat_img">
		</div>
		  
		<div class="input-wrap mt-2">
			<textarea  class='form-control' name="cat_desc" placeholder='<?= $text_desc_ph?>'></textarea>
		</div>
		  
		  <br>
		  <br>
		  <input type="submit"	name="add" value="<?= $text_add_btn ?>">
	</fieldset>
</form>

<?php 
if(isset($result))
	{ ?>

	<div class="alert alert-success" role="alert">
  		Add Done
	</div>

<?php } ?>

