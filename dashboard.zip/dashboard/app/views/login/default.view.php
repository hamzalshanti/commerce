<title><?= $title; ?></title>
</head>

<body class="login-body">
	


<?php 

	
 ?>

<div class="login-outter">
		<div class="login-icon"><i class="fas fa-user"></i></div>
		<div class="login-inner">
			<h3>Login</h3>
			<form method="post" autocomplete="no">
				<input type="text" placeholder="User Name" name="user_name" autocomplete="new-text">
				<input type="password" placeholder="Password" name="password" autocomplete="new-password">
				<input type="submit" name="login" value="Login">
			</form>
		</div>
</div>