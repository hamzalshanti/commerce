
<h2 class="emp-title"><?= $text_view_title ?></h2>

<div class="table-container">
<table id="table_id" class="display">
	<thead>
        <tr>
            <th><?= $text_id ?></th>
			<th><?= $text_name ?></th>
			<th><?= $text_price ?></th>
			<th><?= $text_rate ?></th>
			<th><?= $text_options ?></th>
        </tr>
    </thead>
    <tbody>
<?php 
	if(!isset($item))
	{
		Echo 'No Data Found';
	}
	else{
	$count = 1;
	while ($it = mysqli_fetch_assoc($item)) {
?>
	<tr>
		<td><?php echo $count++ ?></td>
		<td><?php echo $it['item_name'] ?></td>
		<td><?php echo $it['item_price'] ?></td>
		<td><?php echo $it['item_rate'] ?></td>
		<td><a href="<?php echo 'http://localhost/commerce/dashboard/public/item/edit/' . $it['id'] ?>"><i class="far fa-edit"></i>&nbsp;</a> &nbsp;
		<a href="<?php echo 'http://localhost/commerce/dashboard/public/item/delete/' . $it['id'] ?>" onclick="confirm('Are You Sure?')"><i class="far fa-trash-alt"></i>&nbsp;</a></td>
	</tr>
<?php
	}
	}
?>
    </tbody>
</table>
</div>

<!-- <?php 
if(isset($add))
	{ ?>

	<div class="alert alert-success" role="alert">
  		Add Done
	</div>

<?php } ?>
 -->