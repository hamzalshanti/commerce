
	<?php 
	$it = mysqli_fetch_assoc($item);
	 ?>
<form method="post" enctype="multipart/form-data">
	<fieldset class="add-form">
		<legend><?= $text_legend ?></legend>
	  
	  	<div class="input-wrap">
	  		<input type="text" id="fname" name="item_name" placeholder='<?= $text_name_ph?>' value="<?php echo $it['item_name'] ?>">
	  		<input type="text" id="lname" name="item_price" placeholder='<?= $text_price_ph?>' value="<?php echo $it['item_price']?>">
	  		<input type="text" id="lname" name="item_rate" placeholder='<?= $text_rate_ph?>' value="<?php echo $it['item_rate']?>">			  
	  	</div>
	  	
	  	<div class="input-wrap">
			<input type="file" name="item_img">
			<input type="number" name="item_qty" placeholder="<?= $text_qty_ph ?>" value="<?= $it['item_qty']?>">
		</div>

		<div class="input-wrap mt-2">
			<textarea  class='form-control' name="item_desc" placeholder='<?= $text_desc_ph?>'><?= $it['item_desc']?></textarea>
		</div>

		<div class="input-wrap">
			<select name="category_id"  class="form-control">
				<option value="0">uncategorized</option>
				<?php 
				while ($cat = mysqli_fetch_assoc($category)) {
					?>
				<option value="<?= $cat['id']; ?>" <?php echo ($it['category_id'] == $cat['id']) ? 'selected' : ''; ?> ><?= $cat['cat_name']; ?></option>	
				<?php
				}

				 ?>
			</select>
		</div>

	  	<br>
	  	<br>
	  	<input type="submit" name="edit" value="<?= $text_edit_btn?>">
	</fieldset>
</form>

<?php 

if(isset($result))
	{ ?>

	<div class="alert alert-success" role="alert">
  		Edit Done
	</div>

<?php } ?>



