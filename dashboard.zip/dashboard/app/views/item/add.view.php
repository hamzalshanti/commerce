
<form method="post" enctype="multipart/form-data">
	<fieldset class="add-form">
		<legend><?= $text_legend ?></legend>
		  
		<div class="input-wrap">
			  <input type="text"  name="item_name" placeholder='<?= $text_name_ph?>'>
			  <input type="text"  name="item_price" placeholder='<?= $text_price_ph?>'>
			  <input type="text" name="item_rate" placeholder='<?= $text_rate_ph?>'>			  
		</div>
		  
		<div class="input-wrap">
			<input type="file" name="item_img">
			<input type="number" name="item_qty" placeholder="<?= $text_qty_ph ?>">
		</div>

		<div class="input-wrap py-1">
			<textarea  class='form-control' name="item_desc" placeholder='<?= $text_desc_ph?>'></textarea>
		</div>

		<div class="input-wrap py-1">
			<select name="category_id"  class="form-control">
				<option value="0">uncategorized</option>
				<?php 
				while ($cat = mysqli_fetch_assoc($category)) {
					?>
				<option value="<?= $cat['id']; ?>"><?= $cat['cat_name']; ?></option>	
				<?php
				}

				 ?>
			</select>
		</div>
		  
		  <br>
		  <br>
		  <input type="submit"	name="add" value="<?= $text_add_btn?>">
	</fieldset>
</form>


