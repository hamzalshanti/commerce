
<h2 class="emp-title"><?= $text_view_title ?></h2>

<div class="table-container">
<table id="table_id" class="display">
	<thead>
        <tr>
            <th><?= $text_id ?></th>
			<th><?= $text_name ?></th>
			<th><?= $text_email ?></th>
			<th><?= $text_position ?></th>
			<th><?= $text_options ?></th>
        </tr>
    </thead>
    <tbody>
<?php 
	if(!isset($user))
	{
		Echo 'No Data Found';
	}
	else{
	$count = 1;
	while ($user_array = mysqli_fetch_assoc($user)) {
?>
	<tr>
		<td><?php echo $count++ ?></td>
		<td><?php echo $user_array['user_name'] ?></td>
		<td><?php echo $user_array['email'] ?></td>
		<td><?php echo $user_array['position'] ?></td>
		<td><a href="<?php echo 'http://localhost/commerce/dashboard/public/user/edit/' . $user_array['id'] ?>"><i class="far fa-edit"></i>&nbsp;</a> &nbsp;
		<a href="<?php echo 'http://localhost/commerce/dashboard/public/user/delete/' . $user_array['id'] ?>" onclick="confirm('Are You Sure?')"><i class="far fa-trash-alt"></i>&nbsp;</a></td>
	</tr>
<?php
	}
	}
?>
    </tbody>
</table>
</div>

