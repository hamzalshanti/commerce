
	<?php 
	$user_array = mysqli_fetch_assoc($user);
	 ?>
<form method="post" enctype="multipart/form-data">
	<fieldset class="add-form">
		<legend><?= $text_legend ?></legend>
	  
	  	<div class="input-wrap">
	  		<input type="text"  name="user_name" placeholder='<?= $text_name_ph?>' value="<?php echo $user_array['user_name'] ?>">
	  		<input type="email"  name="email" placeholder='<?= $text_email_ph?>' value="<?php echo $user_array['email']?>">  
	  	</div>

	  	<div class="input-wrap">
	  		<input type="password"  name="password" placeholder='<?= $text_pass_ph?>'>
	  		<input type="password"  name="confirm_password" placeholder='<?= $text_confirm_pass_ph?>'>
	  	</div>

	  	
  		<div class="input-wrap">
			<select name="position" id="" class="form-control">
				<option value="Manager" selected="selected"><?= $text_position_user_ph?></option>
				<option value="User"><?= $text_position_manager_ph?></option>

			</select>	
		</div> 

	  	<div class="input-wrap">
			 <input type="file"  name="user_img">	
		</div>
	  	
	  	<br>
	  	<br>
	  	<input type="submit" name="edit" value="<?= $text_edit_btn?>">
	</fieldset>
</form>

<?php 

if(isset($result))
	{ ?>

	<div class="alert alert-success" role="alert">
  		Edit Done
	</div>

<?php } ?>



