
<form method="post" enctype="multipart/form-data">
	<fieldset class="add-form">
		<legend><?= $text_legend ?></legend>
		  
		<div class="input-wrap">
			  <input type="text"  name="user_name" placeholder='<?= $text_name_ph?>'>
			  <input type="email"  name="email" placeholder='<?= $text_email_ph?>'>			  
		</div>
		

		<div class="input-wrap">
			 <input type="password"  name="password" placeholder='<?= $text_pass_ph?>' autocomplete="new-password">
			 <input type="password"  name="confirm_password" placeholder='<?= $text_confirm_pass_ph?>'>
		</div> 


		<div class="input-wrap">
			 <input type="file"  name="user_img">	
		</div> 

		<div class="input-wrap">
			<select name="position" id="" class="form-control">
				<option value="Manager" selected="selected"><?= $text_position_user_ph?></option>
				<option value="User"><?= $text_position_manager_ph?></option>

			</select>	
		</div> 
		  
		  <br>
		  <br>
		  <input type="submit"	name="add" value="<?= $text_add_btn ?>">
	</fieldset>
</form>

<?php 
if(isset($result))
	{ ?>

	<div class="alert alert-success" role="alert">
  		Add Done
	</div>

<?php } ?>

