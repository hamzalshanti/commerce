

<!--start of row-->
<div class="row p-2">
	<!--start of co-->
	<div class="col-12">
		
		<!-- start of row-->
		<div class="row">
			<!--start of col-->
			<div class="col-6 col-md-3 p-2">
				<!--start of card-->
				<div class="card stat stat-users">
					<div class="stat-title">
						<i class="fas fa-user"></i>
						<span><?= $users ?></span>
					</div>
					<!--end of stat-title-->
					<div class="stat-num">
						<span><?= $user_counts ?></span>
					</div>
				</div>
				<!--end of card-->
			</div>
			<!--end of col-->

			<!--start of col-->
			<div class="col-6 col-md-3 p-2">
				<!--start of card-->
				<div class="card stat stat-categories">
					<div class="stat-title">
						<i class="fas fa-align-left"></i>
						<span><?= $categories ?></span>
					</div>
					<!--end of stat-title-->
					<div class="stat-num">
						<span><?= $category_counts ?></span>
					</div>
				</div>
				<!--end of card-->
			</div>
			<!--end of col-->

			<!--start of col-->
			<div class="col-6 col-md-3 p-2">
				<!--start of card-->
				<div class="card stat stat-items">
					<div class="stat-title">
						<i class="fas fa-box"></i>
						<span><?= $items ?></span>
					</div>
					<!--end of stat-title-->
					<div class="stat-num">
						<span><?= $item_counts ?></span>
					</div>
				</div>
				<!--end of card-->
			</div>
			<!--end of col-->

			<!--start of col-->
			<div class="col-6 col-md-3 p-2">
				<!--start of card-->
				<div class="card stat stat-sales">
					<div class="stat-title">
						<i class="fas fa-shopping-cart"></i>
						<span><?= $sales ?></span>
					</div>
					<!--end of stat-title-->
					<div class="stat-num">
						<span>6820</span>
					</div>
				</div>
				<!--end of card-->
			</div>
			<!--end of col-->
		</div>
		<!--end of row-->		
			</div>
			<!--end of col-->

			<!--start of col-->
			<div class="col-12">
				<div class="row chart-wrraper">
					<div class="col-12 col-md-6 p-3">
						<div class="card">
						  <div class="card-header">
						  <i class="fas fa-chart-area"></i>&nbsp;<?= $stat1 ?>
						  </div>
						  <div class="card-body">
						    <canvas id="myChart"></canvas>
						  </div>
						</div>
					</div>
					<div class="col-12 col-md-6 p-3">
						<div class="card" style="height: 100%">
						  <div class="card-header">
						    <i class="far fa-user"></i>&nbsp;<?= $last_users ?>
						  </div>
						  <div class="card-body">
						  	<table class="stat_table">
								<thead>
									<tr>
										<th><?= $text_user_table_username ?></th>
										<th><?= $text_user_table_name ?></th>
										<th><?= $text_user_table_options ?></th>
									</tr>
								</thead>
								<tbody>
									
									<tr>
										<td>hamzasahnti</td>
										<td>Hamza</td>
										<td>
											<a href="" class="options approve"><i class="far fa-check-circle"></i></a>&nbsp;
											<a href="" class="options cancel"><i class="far fa-times-circle"></i></a>
										</td>
									</tr>

									<tr>
										<td>medohaytham</td>
										<td>Mahmoud</td>
										<td>
											<a href="" class="options approve"><i class="far fa-check-circle"></i></a>&nbsp;
											<a href="" class="options cancel"><i class="far fa-times-circle"></i></a>
										</td>
									</tr>

									<tr>
										<td>ameersh</td>
										<td>Ameer</td>
										<td>
											<a href="" class="options approve"><i class="far fa-check-circle"></i></a>&nbsp;
											<a href="" class="options cancel"><i class="far fa-times-circle"></i></a>
										</td>
									</tr>

									<tr>
										<td>ahmedalshanty</td>
										<td>Ahmed</td>
										<td>
											<a href="" class="options approve"><i class="far fa-check-circle"></i></a>&nbsp;
											<a href="" class="options cancel"><i class="far fa-times-circle"></i></a>
										</td>
									</tr>

								</tbody>
							</table>
						  	 
						  </div>
				</div>
				<!--end of card-->
					</div>
				</div>				
			</div>
			<!--end of col-->
			
			<!--start of col-->
			<div class="col-12">

				<div class="row chart-wrraper">
					
					<!--start of inner col-->
					
					<div class="col-12 col-md-6 p-3">
						<div class="card" style="height: 100%">
						  <div class="card-header">
						    <i class="far fa-calendar"></i>&nbsp;<?= $last_orders ?>
						  </div>
						  <div class="card-body">
						    <table class="stat_table">
								<thead>
									<tr>
										<th><?= $text_order_table_name ?></th>
										<th><?= $text_order_table_item ?></th>
										<th><?= $text_order_table_quntitiy ?></th>
										<th><?= $text_order_table_status ?></th>
									</tr>
								</thead>
								<tbody>
									
									<tr>
										<td>Hamza</td>
										<td>HeadPhone</td>
										<td>500</td>
										<td>
											<a href="" class="options approve"><i class="far fa-check-circle"></i></a>
										</td>
									</tr>

									<tr>
										<td>Hamza</td>
										<td>HeadPhone</td>
										<td>500</td>
										<td>
											<a href="" class="options approve"><i class="far fa-check-circle"></i></a>
										</td>
									</tr>

									<tr>
										<td>Hamza</td>
										<td>HeadPhone</td>
										<td>500</td>
										<td>
											<a href="" class="options approve"><i class="far fa-check-circle"></i></a>
										</td>
									</tr>

									<tr>
										<td>Hamza</td>
										<td>HeadPhone</td>
										<td>500</td>
										<td>
											<a href="" class="options approve"><i class="far fa-check-circle"></i></a>
										</td>
									</tr>

								</tbody>
							</table> 
						</div>
				</div>
				<!--end of card-->
					</div>
					
					<!--end of inner col-->
					
					<!--start of inner col-->
					<div class="col-12 col-md-6 p-3">
						<div class="card">
						  <div class="card-header">
						  <i class="fas fa-chart-pie"></i>&nbsp;<?= $stat2 ?>
						  </div>
						  <div class="card-body">
						    <canvas id="my"></canvas>
						  </div>
						</div>
					</div>
					<!--end of inner col-->


				</div>
			</div>
			<!--end of col-->

		</div>
		<!--end of row-->

