<?php

namespace PHPMVC\Controllers;
use PHPMVC\Models\AbstractModel;
class LoginController extends AbstractController
{
	public function defaultAction()
	{

		//Login Check start

		$this->checkSession();



		//Login Check end

		if(isset($_POST['login'])) {
			$user_name = htmlspecialchars($_POST['user_name']);
			$password = htmlspecialchars($_POST['password']);
			$sql = "SELECT * FROM users WHERE position = 'Manager' ";
			$conn = mysqli_connect('localhost', 'root', '', 'ecommerce');
			$result = mysqli_query($conn,$sql);
			while ($data = mysqli_fetch_assoc($result) ) {

				if($data['user_name'] == $user_name && $data['password'] == $password){
				$_SESSION['admin'] 		= $user_name;
				$_SESSION['admin_id'] 	= $data['id'];
			}

			}


			if(isset($_SESSION['admin'])) {
		        header('Location: http://localhost/commerce/dashboard/public');
			}

	}
	$this->_view();

}
			

		protected function _view()
	{

				$this->_lang->load('login\default');
				$this->_data = $this->_lang->getDictionary();
				$this->_template->setData($this->_data);
				$this->_template->renderLogin();
	}

}

			
