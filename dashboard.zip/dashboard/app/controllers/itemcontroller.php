<?php 


namespace PHPMVC\Controllers;
use PHPMVC\LIB\Database\DatabaseHandler;
use PHPMVC\Models\ItemModel;
use PHPMVC\Models\CategoryModel;
use PHPMVC\LIB\InputFilter;
use PHPMVC\LIB\Helper;

class ItemController extends AbstractController
{
	use InputFilter;
	use Helper;

	public function defaultAction()
	{	
		$this->checkSession();
		$this->_lang->load('template\common');
		$this->_lang->load('item\default');
		$this->_data['item'] = ItemModel::getAll();
		$this->_view();
	}

	public function addAction()
	{	
		$this->checkSession();
		$this->_lang->load('template\common');
		$this->_lang->load('item\add');
		$this->_data['category'] = CategoryModel::getAll();
		if(isset($_POST['add'])){
			$item = new ItemModel();
			$item->item_name 	= $this->filterString($_POST['item_name']);
			$item->item_price 	= $this->filterFloat($_POST['item_price']);
			$item->item_rate 	= $this->filterFloat($_POST['item_rate']);
			$item->item_desc 	= $this->filterString($_POST['item_desc']);
			$item->item_qty 	= $this->filterInt($_POST['item_qty']);
			$item->category_id 	= $_POST['category_id'];

			//IMG
			$item_img = $_FILES['item_img'];
			$ext = pathinfo($_FILES['item_img']['name'], PATHINFO_EXTENSION);
			$name = 'item_'. time() . '_'.rand(). '.' . $ext;
			move_uploaded_file($_FILES['item_img']['tmp_name'], APP_PATH . '\uploads\items\\'. $name);
			$item->item_img = $name;
			//IMG

			if($item->create($item))
			{
				$this->_data['add'] = 'Add Done';
				$this->redirect('http://localhost/commerce/dashboard/public/item/');
			}
			
		}
		$this->_view();
	}


	public function editAction()
	{	
		$this->checkSession();
		$this->_lang->load('template\common');
		$this->_lang->load('item\edit');

		$this->_data['category'] = CategoryModel::getAll();

		$id = filter_var($this->_params[0], FILTER_SANITIZE_NUMBER_INT);

		$sql = "SELECT * FROM items WHERE id = $id";


		$conn = DatabaseHandler::getConn();
		$result = mysqli_query($conn, $sql);
		// if(mysqli_num_rows($result) < 0){

		// }
		$this->_data['item'] = $result;

		if(isset($_POST['edit'])){
			$item = new ItemModel();
			$item->id = $id;
			$item->item_name 	= $this->filterString($_POST['item_name']);
			$item->item_price 	= $this->filterFloat($_POST['item_price']);
			$item->item_rate 	= $this->filterFloat($_POST['item_rate']);
			$item->item_desc 	= $this->filterString($_POST['item_desc']);
			$item->item_qty 	= $this->filterInt($_POST['item_qty']);
			$item->category_id 	= $_POST['category_id'];

			//IMG
			$itm = mysqli_fetch_assoc($result);
			$item->item_img = $itm['item_img'];
			if($_FILES['item_img']['name'] != ''){
			$item_img = $_FILES['item_img'];
			$ext = pathinfo($_FILES['item_img']['name'], PATHINFO_EXTENSION);
			$name = 'item_'. time() . '_'.rand(). '.' . $ext;
			move_uploaded_file($_FILES['item_img']['tmp_name'], APP_PATH . '\uploads\items\\'. $name);
			$item->item_img = $name;
			}
			//IMG

			if($item->edit($item))
			{
				$this->_data['item'] = mysqli_query($conn, $sql);
				$this->_data['result'] = 'Edit Done';
			}
			
		}
		$this->_view();
	}


	public function deleteAction()
	{	
		$this->checkSession();
		$this->_lang->load('template\common');
		
		$id = filter_var($this->_params[0], FILTER_SANITIZE_NUMBER_INT);

		$sql = "SELECT * FROM items WHERE id = $id";

		

		$conn = DatabaseHandler::getConn();
		$result = mysqli_query($conn, $sql);
		if(mysqli_num_rows($result) < 0){

		}


			$item = new ItemModel();
			
			$item->item_id = $id;
			if($item->delete($item))
			{
				$this->redirect('http://localhost/commerce/dashboard/public/item/');
			}
			


	}

}
