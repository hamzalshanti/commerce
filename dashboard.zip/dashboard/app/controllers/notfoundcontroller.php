<?php 

namespace PHPMVC\Controllers;
class NotFoundController extends AbstractController
{

}