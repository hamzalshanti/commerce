<?php

namespace PHPMVC\Controllers;
use PHPMVC\Models\UserModel;
class AbstractController
{


	protected $_controller;
	protected $_action;
	protected $_params;
	protected $_data = [];
	protected $_template;
	protected $_lang;
	
	public function notFoundAction(){
		$this->_view();
	}
	public function setController($controllerName){
		$this->_controller = $controllerName;
	}

	public function setAction($actionName){
		$this->_action = $actionName;	
	}

	public function setParams($params){
		$this->_params = $params;	
	}

	public function setTemplate($template){
		$this->_template = $template;	
	}

	public function setLang($lang){
		$this->_lang = $lang;	
	}

	public function checkSession(){
		

		if($this->_controller != 'login') {
    		if(!isset($_SESSION['admin'])) {
        	header('Location: http://localhost/commerce/dashboard/public/login');
    		}
		}
		if($this->_controller == 'login') {
    		if(isset($_SESSION['admin'])) {
        	header('Location: http://localhost/commerce/dashboard/public/');
    		}
		}
	} 

	protected function _view()
	{

		if(isset($_SESSION['admin'])){
		$this->_data['user_nav'] = UserModel::getAll('WHERE id = '. $_SESSION['admin_id'] );
		}

		if($this->_action == 'notFoundAction')
		{
			$notfound =  VIEWS_PATH . 'notfound' . DS . 'notfound.view.php';
			$this->_template->setActionView($notfound);
			$this->_template->renderApp();
		}
		else{
			$view = VIEWS_PATH . $this->_controller . DS . $this->_action . '.view.php';
			if(file_exists($view))
			{
				$this->_data = array_merge($this->_data, $this->_lang->getDictionary());
				$this->_template->setData($this->_data);
				$this->_template->setActionView($view);
				$this->_template->renderApp();
			}
			else
			{
				require_once VIEWS_PATH . 'notfound' . DS . 'noview.view.php';
			}
		}
	}
}