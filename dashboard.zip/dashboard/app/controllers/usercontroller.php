<?php 


namespace PHPMVC\Controllers;
use PHPMVC\LIB\Database\DatabaseHandler;
use PHPMVC\Models\UserModel;
use PHPMVC\LIB\InputFilter;
use PHPMVC\LIB\Helper;

class UserController extends AbstractController
{
	use InputFilter;
	use Helper;

	public function defaultAction()
	{	
		$this->checkSession();
		$this->_lang->load('template\common');
		$this->_lang->load('user\default');
		$this->_data['user'] = UserModel::getAll();
		$this->_view();
	}

	public function addAction()
	{	
		$this->checkSession();
		$this->_lang->load('template\common');
		$this->_lang->load('user\add');
		$this->_data['user'] = UserModel::getAll();
		if(isset($_POST['add'])){
			$user = new UserModel();
			$user->user_name 	= $this->filterString($_POST['user_name']);
			$user->email 	= $this->filterString($_POST['email']);
			$user->position 	= $_POST['position'];
			$user->password = $this->filterString($_POST['password']);

			//IMG

			$user_img = $_FILES['user_img'];
			$ext = pathinfo($_FILES['user_img']['name'], PATHINFO_EXTENSION);
			$name = 'user_'. time() . '_'.rand(). '.' . $ext;
			move_uploaded_file($_FILES['user_img']['tmp_name'], APP_PATH . '\uploads\users\\'. $name);
			$user->user_img = $name;


			//IMG

			$passValidation = $_POST['password'] == $_POST['confirm_password'];
			if($user->create($user) && $passValidation)
			{
				$this->_data['add'] = 'Add Done';
				$this->redirect('http://localhost/commerce/dashboard/public/user/');
			}
			
		}
		$this->_view();
	}

		public function editAction()
	{	
		$this->checkSession();
		$this->_lang->load('template\common');
		$this->_lang->load('user\edit');

		$id = filter_var($this->_params[0], FILTER_SANITIZE_NUMBER_INT);

		$sql = "SELECT * FROM users WHERE id = $id";


		$conn = DatabaseHandler::getConn();
		$result = mysqli_query($conn, $sql);
		// if(mysqli_num_rows($result) < 0){

		// }
		$this->_data['user'] = $result;

		if(isset($_POST['edit'])){
			$user = new UserModel();
			$user->id = $id;
			$user->user_name = $this->filterString($_POST['user_name']);
			$user->email = $this->filterString($_POST['email']);
			$user->position = $_POST['position'];
			$passValidation = true;
			$user_array = mysqli_fetch_assoc($result);
			$user->password = $user_array['password'];


			//IMG
			$user->user_img = $user_array['user_img'];
			if($_FILES['user_img']['name'] != ''){
			$user_img = $_FILES['user_img'];
			$ext = pathinfo($_FILES['user_img']['name'], PATHINFO_EXTENSION);
			$name = 'user_'. time() . '_'.rand(). '.' . $ext;
			move_uploaded_file($_FILES['user_img']['tmp_name'], APP_PATH . '\uploads\users\\'. $name);
			$user->user_img = $name;
			}
			//IMG

			if($_POST['password'] != ''){
				$passValidation = $_POST['password'] == $_POST['confirm_password'];
				if($passValidation)
					$user->password = $this->filterString($_POST['password']);
				$this->_data['user'] = mysqli_query($conn, $sql);
			}
			
			if($user->edit($user) && $passValidation)
			{
				$this->_data['user'] = mysqli_query($conn, $sql);
				$this->_data['result'] = 'Edit Done';
			}
			
		}
		$this->_view();
	}


	public function deleteAction()
	{	
		$this->checkSession();
		$this->_lang->load('template\common');
		
		$id = filter_var($this->_params[0], FILTER_SANITIZE_NUMBER_INT);

		$sql = "SELECT * FROM users WHERE id = $id";

		

		$conn = DatabaseHandler::getConn();
		$result = mysqli_query($conn, $sql);
		if(mysqli_num_rows($result) < 0){

		}


			$user = new UserModel();
			
			$user->id = $id;
			if($user->delete($user))
			{
				$this->redirect('http://localhost/commerce/dashboard/public/user');
			}
			


	}



	

}
