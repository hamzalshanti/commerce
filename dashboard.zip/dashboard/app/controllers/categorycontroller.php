<?php 


namespace PHPMVC\Controllers;
use PHPMVC\LIB\Database\DatabaseHandler;
use PHPMVC\Models\CategoryModel;
use PHPMVC\LIB\InputFilter;
use PHPMVC\LIB\Helper;

class CategoryController extends AbstractController
{
	use InputFilter;
	use Helper;

	public function defaultAction()
	{	
		$this->checkSession();
		$this->_lang->load('template\common');
		$this->_lang->load('category\default');
		$this->_data['category'] = CategoryModel::getAll();
		$this->_view();
	}

	public function addAction()
	{	
		$this->checkSession();
		$this->_lang->load('template\common');
		$this->_lang->load('category\add');
		if(isset($_POST['add'])){
			$category = new CategoryModel();
			$category->cat_name = $this->filterString($_POST['cat_name']);
			$category->cat_desc = $this->filterString($_POST['cat_desc']);

			//IMG
			$cat_img = $_FILES['cat_img'];
			$ext = pathinfo($_FILES['cat_img']['name'], PATHINFO_EXTENSION);
			$name = 'cat_'. time() . '_'.rand(). '.' . $ext;
			move_uploaded_file($_FILES['cat_img']['tmp_name'], APP_PATH . '\uploads\categories\\'. $name);
			$category->cat_img = $name;
			//IMG

			if($category->create($category))
			{
				$this->_data['result'] = 'Add Done';
			}
			
		}
		$this->_view();
	}


	public function editAction()
	{	
		$this->checkSession();
		$this->_lang->load('template\common');
		$this->_lang->load('category\edit');

		$id = filter_var($this->_params[0], FILTER_SANITIZE_NUMBER_INT);

		$sql = "SELECT * FROM categories WHERE id = $id";


		$conn = DatabaseHandler::getConn();
		$result = mysqli_query($conn, $sql);
		// if(mysqli_num_rows($result) < 0){

		// }
		$this->_data['category'] = $result;

		if(isset($_POST['edit'])){
			$category = new CategoryModel();
			$category->id = $id;
			$category->cat_name = $this->filterString($_POST['cat_name']);
			$category->cat_desc = $this->filterString($_POST['cat_desc']);

			//IMG
			$cat = mysqli_fetch_assoc($result);
			$category->cat_img = $cat['cat_img'];
			if($_FILES['cat_img']['name'] != ''){
			$cat_img = $_FILES['cat_img'];
			$ext = pathinfo($_FILES['cat_img']['name'], PATHINFO_EXTENSION);
			$name = 'cat_'. time() . '_'.rand(). '.' . $ext;
			move_uploaded_file($_FILES['cat_img']['tmp_name'], APP_PATH . '\uploads\categories\\'. $name);
			$category->cat_img = $name;
			}
			//IMG

			if($category->edit($category))
			{
				$this->_data['category'] = mysqli_query($conn, $sql);
				$this->_data['result'] = 'Edit Done';
			}
			
		}
		$this->_view();
	}


	public function deleteAction()
	{	
		$this->checkSession();
		$this->_lang->load('template\common');
		
		$id = filter_var($this->_params[0], FILTER_SANITIZE_NUMBER_INT);

		$sql = "SELECT * FROM categories WHERE id = $id";

		

		$conn = DatabaseHandler::getConn();
		$result = mysqli_query($conn, $sql);
		if(mysqli_num_rows($result) < 0){

		}


			$category = new CategoryModel();
			
			$category->id = $id;
			if($category->delete($category))
			{
				$this->redirect('http://localhost/commerce/dashboard/public/category/');
			}
			


	}

}
