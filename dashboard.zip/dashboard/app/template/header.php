  
<header>
  <nav class="header">
    <span><i class="fas fa-bars"></i></span>
    <span><?= $text_board ?></span>
    <!--start of acc-options-->
    <div class="acc-options">
      <ul>
        <li>
          <div class='alert-container'>
            <i class="far fa-bell"></i>
            <span>1</span>
          </div>
        </li>

        <li><i class="fas fa-comment-dots"></i></li>
        
        <li><i class="fas fa-cog"></i></li>

        <!--start of li-drop-down-->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-globe"></i>
          </a>
  
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="http://localhost/commerce/dashboard/public/language/ar">
                <?= $text_ar ?>
              </a>

              <a class="dropdown-item" href="http://localhost/commerce/dashboard/public/language/en">
                <?= $text_en ?>
              </a>

          </div>
          

        </li>
        <!--end of li-drop-down-->

        




      </ul>
      <!--end of ulist-->
    </div>
  </nav>     
</header>