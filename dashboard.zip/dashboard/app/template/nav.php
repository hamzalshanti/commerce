
            <nav class="navigator">
                <ul>
                	<li class="account-info">
                		<div class="inner-acc-info">
                            <?php 
                                $user_nav = mysqli_fetch_assoc($user_nav);
                             ?>
							<img src="http://localhost/commerce/dashboard/app/uploads/users/<?= $user_nav['user_img']; ?>" alt="">
							<h5><?= $user_nav['user_name']; ?></h5>
							<h6><?= $user_nav['position']; ?></h6>
						</div>
                	</li>	
                	<li><a href="http://localhost/commerce/dashboard/public/" class="menu-item"><i class="far fa-chart-bar"></i>&nbsp;<?= $text_show_stat ?></a></li>

                    <!--start of parent -menu-->
                    <li class="parent-menu">
                        <span class="menu-header"><i class="fas fa-align-left"></i>&nbsp;<?= $text_categories ?></span>
                        <ul>

                            <li>
                                <a href="http://localhost/commerce/dashboard/public/category" class="menu-item"><i class="fas fa-tv"></i>&nbsp;<?= $text_show_categories ?></a>
                            </li>

                            
                             <li>
                                <a href="http://localhost/commerce/dashboard/public/category/add" class="menu-item"><i class="far fa-plus-square"></i>&nbsp;<?= $text_add_category ?></a>
                             </li>   
                    
                        </ul>
                    </li>
                    <!--end of parent-menu-->

                    <!--start of parent-menu-->
                    <li class="parent-menu">
                        <span class="menu-header"><i class="fas fa-tags"></i>&nbsp;<?= $text_items ?></span>
                        <ul>

                            <li>
                                <a href="http://localhost/commerce/dashboard/public/item" class="menu-item"><i class="fas fa-tv"></i>&nbsp;<?= $text_show_items ?></a>
                            </li>

                            
                             <li>
                                <a href="http://localhost/commerce/dashboard/public/item/add" class="menu-item"><i class="far fa-plus-square"></i>&nbsp;<?= $text_add_item ?></a>
                             </li>   
                    
                        </ul>
                    </li>
                    <!--end of parent menu-->

                    <!--start of parent -menu-->
                    <li class="parent-menu">
                        <span class="menu-header"><i class="fas fa-user"></i>&nbsp;<?= $text_users ?></span>
                        <ul>

                            <li>
                                <a href="http://localhost/commerce/dashboard/public/user" class="menu-item"><i class="fas fa-tv"></i>&nbsp;<?= $text_show_users ?></a>
                            </li>

                            
                             <li>
                                <a href="http://localhost/commerce/dashboard/public/user/add" class="menu-item"><i class="far fa-plus-square"></i>&nbsp;<?= $text_add_user ?></a>
                             </li>   
                    
                        </ul>
                    </li>
                    <!--end of parent-menu-->
                </ul>
            </nav>
            <div class="view pl-2">