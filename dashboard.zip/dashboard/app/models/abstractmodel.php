<?php 

namespace PHPMVC\Models;
use PHPMVC\LIB\Database\DatabaseHandler;

class AbstractModel
{

	public static function bulidValues($ob)
	{
		$para = '';
		foreach (static::$tableSchema as $col => $type) {
			if($type == 'str')
			$para .=  "'" . $ob->$col . "'" . ',';
			else
			$para .=  $ob->$col . ',';

		}
			return trim($para, ',');
	}

	public static function bulidCols($ob)
	{
		$para = '';
		foreach (static::$tableSchema as $col => $type) {
			$para .=  $col  . ',';

		}
			return trim($para, ',');
	}


	public static function bulidUpdate($ob)
	{
		$para = '';
		foreach (static::$tableSchema as $col => $type) {
			$para .=  $col  . ' = ';
			if($type == 'str')
			$para .=  "'" . $ob->$col . "'" . ',';
			else
			$para .=  $ob->$col . ',';

		}
			return trim($para, ',');
	}


	public static function create($ob)
	{
		$conn = DatabaseHandler::getConn();

		$sql = "INSERT INTO ". static::$tableName . " (" . self::bulidCols($ob) . ") "  . " VALUES (" . self::bulidValues($ob) . ')';
		$result = mysqli_query($conn, $sql);
		return $result;

	}

	public static function edit($ob)
	{

		
		$conn = DatabaseHandler::getConn();

		$sql = "UPDATE  ". static::$tableName . " SET " . self::bulidUpdate($ob) . " WHERE id = $ob->id";
		$result = mysqli_query($conn, $sql);
		return $result;


	}

	public static function delete($ob)
	{

		
		$conn = DatabaseHandler::getConn();
		$sql = "DELETE FROM  " . static::$tableName . " WHERE id = $ob->id" ;
		$result = mysqli_query($conn, $sql);
		return $result;


	}

	public function getAll($predict='')
	{
		$conn = DatabaseHandler::getConn();
		$sql = "SELECT * FROM " . static::$tableName . ' ' . $predict;
		$result = mysqli_query($conn, $sql);
		return $result;		
	}

		public function getCounts()
	{
		$conn = DatabaseHandler::getConn();
		$sql = "SELECT * FROM " . static::$tableName;
		$result = mysqli_query($conn, $sql);
		return mysqli_num_rows($result);		
	}
}